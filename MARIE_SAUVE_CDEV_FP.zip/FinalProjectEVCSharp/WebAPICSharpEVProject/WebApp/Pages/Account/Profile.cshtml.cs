using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApp.Pages.Account
{
    public class ProfileModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
