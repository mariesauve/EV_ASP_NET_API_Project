﻿namespace WebAPICSharpEVProject.Filters.ExceptionFilters
{
    public class SCookie_HandleUpdateExceptionsFilterAttribute
    {
    }
}
